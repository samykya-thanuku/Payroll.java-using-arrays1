package com.cg.payroll.services;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public interface PayrollServices {

	int acceptAssociateDetails(String firstName, String lastName, String emailId, String department, String designation,
			String pancard, float yearlyInvestmentUnder80C, float basicSalary, float epf, float companyPf,
			float accountNumber, String bankName, String ifscCode);

	float calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException ;

	Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException;

	Associate[] getAssociateDetails();

	boolean acceptAssociateDetailsForUpdate(int associateId, String firstName, String lastName, String emailId,
			String department, String designation, String pancard, float yearlyInvestmentUnder80C, float basicSalary,
			float epf, float companyPf, float accountNumber, String bankName, String ifscCode);
	boolean delete(Associate associate);

}